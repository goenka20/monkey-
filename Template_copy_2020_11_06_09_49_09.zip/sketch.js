
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score

function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstaceImage = loadImage("obstacle.png");
 
}



function setup() {
  banana=createSprite(200,100,40,40);
  banana.addAnimation=("banana.png")

  
}


function draw() {
  background(180);
  if(keyDown("space")&& monkey. y >= 100) {
        monkey.velocityY = -12;
        jumpSound.play();
    }
  monkey.collide(invisibleGround);
  
drawSprites();
  
}
if (frameCount % 80 === 0){
  var monkey = createSprite(600,165,10,40);
  monkey.y=120,200;
  monkey.y=-120,-200;
  monkey.lifetime=200;
  
}
if (frameCount % 200 === 0){
  var obstacle = createSprite(600,165,10,40);
  obstacle.y=120,200;
  obstacle.y=-120,-200;
  obstacle.lifetime=200;
}
  




